// import { useState } from 'react'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import './App.css'
import Home from './Components/Home/Home'
import InteractiveForm from './Components/InteractiveForm/InteractiveForm';
import NotFound from './Components/NotFound/NotFound';
import MovieSelection from './Components/MovieSelection/MovieSelection';
import Layout from './Components/Layout/Layout';

function App() {

  let router = createBrowserRouter([
    {
      path: "",
      element: <Layout />,
      children: [
        { index: true, element: <Home /> },
        { path: 'form', element: <InteractiveForm /> },
        { path: 'movies', element: <MovieSelection /> },
      ]
    },
    { path: '*', element: <NotFound /> }
  ]);

  return (
    <>
      <RouterProvider router={router}></RouterProvider>
    </>
  )
}

export default App