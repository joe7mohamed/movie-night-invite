import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeart, faArrowRight } from '@fortawesome/free-solid-svg-icons';

function InteractiveForm() {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        genre: '',
        snack: '',
        time: '',
    });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        navigate('/movies');
    };

    return (
        <div className="flex items-center justify-center h-screen bg-pink-50">
            <form onSubmit={handleSubmit} className="bg-white p-8 rounded-lg shadow-lg w-96">
                <h2 className="text-3xl font-bold mb-6 text-red-600">
                    <FontAwesomeIcon icon={faHeart} className="mr-2" /> Let’s Personalize Your Invite
                </h2>
                <div className="mb-6">
                    <label className="block text-gray-700 font-semibold">Favorite Genre:</label>
                    <input
                        type="text"
                        name="genre"
                        value={formData.genre}
                        onChange={handleChange}
                        className="w-full px-4 py-3 mt-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-pink-600"
                        placeholder="e.g., Action, Romance"
                        required
                    />
                </div>
                <div className="mb-6">
                    <label className="block text-gray-700 font-semibold">Preferred Snack:</label>
                    <input
                        type="text"
                        name="snack"
                        value={formData.snack}
                        onChange={handleChange}
                        className="w-full px-4 py-3 mt-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-pink-600"
                        placeholder="e.g., Popcorn, Nachos"
                        required
                    />
                </div>
                <div className="mb-6">
                    <label className="block text-gray-700 font-semibold">Best Time for a Movie:</label>
                    <input
                        type="text"
                        name="time"
                        value={formData.time}
                        onChange={handleChange}
                        className="w-full px-4 py-3 mt-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-pink-600"
                        placeholder="e.g., Evening, Afternoon"
                        required
                    />
                </div>
                <button
                    type="submit"
                    className="w-full mt-8 px-4 py-3 bg-pink-600 text-white rounded-md text-xl font-semibold shadow-lg hover:bg-pink-700 transition-all duration-300"
                >
                    Next <FontAwesomeIcon icon={faArrowRight} className="ml-2" />
                </button>
            </form>
        </div>
    );
}

export default InteractiveForm;
