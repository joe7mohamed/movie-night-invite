import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const movies = [
    { title: 'Inception', synopsis: 'A thief who steals corporate secrets through dream-sharing technology...', trailer: 'https://www.youtube.com/watch?v=YoHD9XEInc0' },
    { title: 'La La Land', synopsis: 'A jazz musician falls in love with an aspiring actress in Los Angeles...', trailer: 'https://www.youtube.com/watch?v=0pdqf4P9MB8' },
    // Add more movies here
];

function MovieSelection() {
    const [selectedMovie, setSelectedMovie] = useState(null);
    const navigate = useNavigate();

    const handleMovieSelect = (movie) => {
        setSelectedMovie(movie);
    };

    const handleNext = () => {
        navigate('/date');
    };

    return (
        <div className="flex items-center justify-center h-screen bg-gray-50">
            <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-4xl">
                <h2 className="text-3xl font-bold mb-6 text-red-600 text-center">Pick a Movie</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {movies.map((movie, index) => (
                        <div
                            key={index}
                            className={`p-6 border rounded-lg cursor-pointer ${selectedMovie === movie ? 'border-red-600' : 'border-gray-300'}`}
                            onClick={() => handleMovieSelect(movie)}
                        >
                            <h3 className="text-lg font-semibold text-gray-800">{movie.title}</h3>
                            <p className="text-sm text-gray-600 mt-2">{movie.synopsis}</p>
                            <a href={movie.trailer} target="_blank" rel="noopener noreferrer" className="text-red-600 underline mt-4 block">Watch Trailer</a>
                        </div>
                    ))}
                </div>
                <button
                    onClick={handleNext}
                    className={`mt-10 w-full px-4 py-3 bg-red-600 text-white rounded-md text-xl font-semibold shadow-lg ${!selectedMovie && 'opacity-50 cursor-not-allowed'}`}
                    disabled={!selectedMovie}
                >
                    Next
                </button>
            </div>
        </div>
    );
}

export default MovieSelection;
