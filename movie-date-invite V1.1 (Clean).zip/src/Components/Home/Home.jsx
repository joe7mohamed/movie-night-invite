
function Home() {


    return (
        <>
            <h1>Hi </h1>
        </>
    );
}

export default Home;