import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function DateSelection() {
    const [date, setDate] = useState('');
    const navigate = useNavigate();

    const handleDateChange = (e) => {
        setDate(e.target.value);
    };

    const handleNext = () => {
        navigate('/confirm');
    };

    return (
        <div className="flex items-center justify-center h-screen bg-gray-50">
            <div className="bg-white p-8 rounded-lg shadow-lg w-full max-w-lg">
                <h2 className="text-3xl font-bold mb-6 text-red-600 text-center">Select a Date and Time</h2>
                <input
                    type="datetime-local"
                    value={date}
                    onChange={handleDateChange}
                    className="w-full px-4 py-3 border rounded-md focus:outline-none focus:ring-2 focus:ring-red-600"
                    required
                />
                <button
                    onClick={handleNext}
                    className={`mt-10 w-full px-4 py-3 bg-red-600 text-white rounded-md text-xl font-semibold shadow-lg ${!date && 'opacity-50 cursor-not-allowed'}`}
                    disabled={!date}
                >
                    Next
                </button>
            </div>
        </div>
    );
}

export default DateSelection;
