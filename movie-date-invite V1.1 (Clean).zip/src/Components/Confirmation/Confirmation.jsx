function Confirmation() {
    return (
        <div className="flex items-center justify-center h-screen bg-gray-50">
            <div className="bg-white p-8 rounded-lg shadow-lg text-center">
                <h2 className="text-4xl font-bold mb-6 text-red-600">You are All Set!</h2>
                <p className="text-xl font-semibold text-gray-800 mb-4">Get ready for a fantastic movie night!</p>
                <div className="bg-red-600 text-white py-3 px-6 rounded-full inline-block text-lg font-semibold">
                    🎉 Confirmation Code: MOVIENIGHT123 🎉
                </div>
            </div>
        </div>
    );
}

export default Confirmation;
